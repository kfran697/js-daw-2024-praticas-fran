let video = document.querySelector('video');
let textZone = document.getElementById('textZone');

video.addEventListener('mousedown', (event) => {
    if (event.button === 0) {
        if (video.paused) {
            video.play();
        } else {
            video.pause();
        }
    } 
});

video.addEventListener('contextmenu', (event) => {
    event.preventDefault();

    const minutes = Math.floor(video.duration / 60);
    const seconds = Math.floor(video.duration % 60);
    textZone.textContent = 'Duración total: ' +  minutes + ' minutos y ' + seconds + ' segundos.';
});
